// Muallif: Ro'ziyev Shohzod
//Sana: 11.11.2014
//Maqsad: Ko'rsatkich adresi va qiymatiga doir misol

#include <iostream>

using namespace std;

int main()
{
    double *kPtr; //Ko'rsatkichni e'lon qilish uchun ko'rsatkich oldidan (*) belgisi qo'yiladi
    double n = 5;

    // & adresni olish amali

    kPtr = &n;
    cout << "n = " << n << endl;
    cout << "*kPtr = " << *kPtr << endl;

    cout << "\nxotira adresi" << endl;
    cout << "n - o'zgaruvchisin joylashgan adres. &n" << &n << endl;
    cout << "Ko'rsatkich ko'rsatayotgan adres. kPtr" << kPtr << endl;
    cout << "Ko'rsatkich joylashgan adres. &kPtr" << &kPtr << endl;

    cout << "\no'zgaruvchilarni xotirada egallagan hajmi" << endl;
    cout << "sizeof(n) = " << sizeof(n) << endl;
    cout << "sizeof(kPtr)= "  << sizeof(kPtr) << endl;

    return 0;
}
