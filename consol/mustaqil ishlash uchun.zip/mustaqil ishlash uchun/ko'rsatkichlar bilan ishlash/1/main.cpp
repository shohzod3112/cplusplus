// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Ko'rsatkich adresi va qiymatiga doir misol

#include <iostream>

using namespace std;

int main()
{
    int *nPtr; //Ko'rsatkichni e'lon qilish uchun ko'rsatkich oldidan (*) belgisi qo'yiladi
    int n = 5;

    // & adresni olish amali

    nPtr = & n;
    cout << "n = " << n << endl;
    cout << "nPtr = " << nPtr << endl;

    // *nPtr bu yerda 15 qiymatini o'zlashtiryapti

    *nPtr = 15;
    cout << "n = " << n << endl;
    cout << "nPtr = " << nPtr << endl;
    cout << "*nPtr = " << *nPtr << endl;

    cout << "\nKo'rsatkichning qiymati,\n";
    cout << "ya'ni ko'rsatkich ko'rsatayotgan adres = " << nPtr << endl;
    cout << "Ko'rsatkich ko'rsatayotgan adres qiymati = "  << *nPtr << endl;

    return 0;
}
