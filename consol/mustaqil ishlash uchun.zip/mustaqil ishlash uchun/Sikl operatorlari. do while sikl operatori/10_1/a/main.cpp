// Muallif: Ro'ziyev Shohzod
// Sana: 05.09.2014
// Maqsad: N natural soni berilgan.Quyidagilarni hisoblovchi programma
// tuzilsin. (do-while sikl operatori orqali)

#include <iostream>

using namespace std;

int main()
{
    int n;
    float k = 1, s = 0;

    cout << "n = "; cin >> n;

    do
{
    s += 1 / k;
    k++;
}   while (k <= n);

    cout << s << endl;

    return 0;
}
