// Muallif: Ro'ziyev Shohzod
// Sana: 05.09.2014
// Maqsad:n natural soni berilgan(n >= 4).Quyidagi qonuniyat asosida
// n ni hisoblovchi programma tuzilsin.(do-while sikl operatori orqali)

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int n;
    float v1 = 0, v2 = 0, v3 = 1.5, v = v3, p, i = 0;

    cout << "n = "; cin >> n;

    do
{
    p = v;
    v = (i + 1) / (i * i + 1) * v3 - v2 * v1;
    v1 = v2; v2 = v3; v3 = p;
    i++;
}   while (i < n);

    cout << v << endl;

    return 0;
}
