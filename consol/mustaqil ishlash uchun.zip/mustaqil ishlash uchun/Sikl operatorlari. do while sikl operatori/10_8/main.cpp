// Muallif: Ro'ziyev Shohzod
// Sana: 05.09.2014
// Maqsad:Noldan farqli bo'lmagan x haqiqiy soni berilgan.
// Quyidagi ifodani hisoblovchi programma tuzilsin.
// (do-while sikl operatori orqali)

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float i = 256, x, s;

    cout << "x = "; cin >> x;

    s = x * x;

    do
{
    s = x * x + i / s;
    i /= 2;
}   while (i > 1);

    s = x / s;
    cout << s << endl;

    return 0;
}
