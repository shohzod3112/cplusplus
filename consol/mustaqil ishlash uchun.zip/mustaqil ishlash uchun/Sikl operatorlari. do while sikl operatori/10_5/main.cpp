// Muallif: Ro'ziyev Shohzod
// Sana: 05.09.2014
// Maqsad:q, r, b, c, d haqiqiy sonlari va n natural soni berilgan(n >= 2).
// Quyidagi qonuniyat asosida xn ni hisoblovchi programma tuzilsin.(do-while sikl operatori orqali)

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int n;
    float q, r, b, c, d, x0, x1, x, xx, k = 1;

    cout << "n = "; cin >> n;
    cout << "q = "; cin >> q;
    cout << "r = "; cin >> r;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;
    cout << "d = "; cin >> d;

    x1 = c; xx = d;
    do
{
    k++;
    x0 = x1; x1 = xx;
    x = q * x1 + r * x0 + b;
    xx = x;
}   while (k < n);

    cout << x << endl;

    return 0;
}
