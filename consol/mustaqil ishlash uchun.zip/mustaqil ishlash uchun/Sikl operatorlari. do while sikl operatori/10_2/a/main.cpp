// Muallif: Ro'ziyev Shohzod
// Sana: 05.09.2014
// Maqsad:n natural soni va x haqiqiy soni berilgan. Quyidagilarni
// hisoblovchi programma tuzilsin.(do-while sikl operatori orqali)

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int n, p = 1, i = 0;
    float dar_x = 1, x, s = 0;

    cout << "n = "; cin >> n;
    cout << "x = "; cin >> x;

    do
{
    i++;
    dar_x *= x;
    p *= i;
    s += dar_x / p;
}   while (i < n);

    cout << s << endl;

    return 0;
}
