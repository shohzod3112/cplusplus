// Muallif: Ro'ziyev Shohzod
// Sana: 05.09.2014
// Maqsad:a0 = a1 = 1 i = 2,3,4,...; bo'lsin.
// Quyidagi qonuniyat asosida xn ni hisoblovchi programma tuzilsin.(do-while sikl operatori orqali)

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int n;
    float a, a0 = 1, a1 = 1, p = 1, i = 1;

    cout << "n = "; cin >> n;

    do
{
    i++;
    a = a0 + a1 / pow(2.0,i - 1);
    a0 = a1;
    a1 = a;
    p *= a;
}   while (i < n);

    cout << p << endl;

    return 0;
}
