// Muallif: Ro'ziyev Shohzod
// Sana: 05.09.2014
// Maqsad:n natural soni berilgan.Quyidagi qonuniyat asosida
// an ni hisoblovchi programma tuzilsin.(do-while sikl operatori orqali)

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int n;
    float a = 1, k = 0;

    cout << "n = "; cin >> n;

    do
{
    k++;
    a = k * a + 1 / k;
}   while (k < n);

    cout << a << endl;

    return 0;
}
