// Muallif: Ro'ziyev Shohzod
// Sana: 05.09.2014
// Maqsad:Quyidagi ifodani hisoblovchi programma tuzilsin.
// (do-while sikl operatori orqali)

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float i = 101, s = 103;

    do
{
    s = i + 1 / s;
    i -= 2;
}   while (i > 0);

    s = 1 / s;
    cout << s << endl;

    return 0;
}
