#ifndef DASTUR_H_INCLUDED
#define DASTUR_H_INCLUDED

int werty(int a, int b)
{
    return a + b;
}

#endif // DASTUR_H_INCLUDED
