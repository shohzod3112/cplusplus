#include <iostream>
#include "header.hpp"
#include "dastur.h"

using namespace std;

int main()
{
    int i, j;

    cout << "i = "; cin >> i;
    cout << "j = "; cin >> j;

    cout << "Yig'indi = " << werty(i, j) << endl;
    ayir(&i, &j);
    cout << "Ayirma = " << i << endl;

    return 0;
}
