#ifndef HEADER_HPP_INCLUDED
#define HEADER_HPP_INCLUDED

void ayir (int *a, int *b)
{
    *a = *a - *b;
}

#endif // HEADER_HPP_INCLUDED
