// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Kiritilgan songa mos ravishda yil oyini chiqaruvchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    int a;

    cout << "a = "; cin >> a;

    switch(a)
{
    case 1: cout << "yanvar" << endl;
        break;
    case 2: cout << "fevral" << endl;
        break;
    case 3: cout << "mart" << endl;
        break;
    case 4: cout << "aprel" << endl;
        break;
    case 5: cout << "may" << endl;
        break;
    case 6: cout << "iyun" << endl;
        break;
    case 7: cout << "iyul" << endl;
        break;
    case 8: cout << "avgust" << endl;
        break;
    case 9: cout << "sentabr" << endl;
        break;
    case 10: cout << "oktabr" << endl;
        break;
    case 11: cout << "noyabr" << endl;
        break;
    case 12: cout << "dekabr" << endl;
        break;
    default: cout << "Bunday yil oyi yo'q!!!" << endl;
}
    return 0;
}
