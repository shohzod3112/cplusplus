// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Kiritilgan n sonini so'z bilan ifodalovchi programma tuzilsin.
// 0 < N < 100

#include <iostream>

using namespace std;

int main()
{
    int a, b, n;

    cout << "n = "; cin >> n;

    a = n / 10;
    b = n % 10;

    switch(a)
{
    case 1: cout << "O'n";
        break;
    case 2: cout << "Yigirma";
        break;
    case 3: cout << "O'ttiz";
        break;
    case 4: cout << "Qirq";
        break;
    case 5: cout << "Ellik";
        break;
    case 6: cout << "Oltmish";
        break;
    case 7: cout << "Yetmish";
        break;
    case 8: cout << "Sakson";
        break;
    case 9: cout << "To'qson";
        break;
}
    switch (b)
{
    case 1: cout << " bir" << endl;
        break;
    case 2: cout << " ikki" << endl;
        break;
    case 3: cout << " uch" << endl;
        break;
    case 4: cout << " to'rt" << endl;
        break;
    case 5: cout << " besh" << endl;
        break;
    case 6: cout << " olti" << endl;
        break;
    case 7: cout << " yetti" << endl;
        break;
    case 8: cout << " sakkiz" << endl;
        break;
    case 9: cout << " to'qqiz" << endl;
        break;
}
     return 0;
}
