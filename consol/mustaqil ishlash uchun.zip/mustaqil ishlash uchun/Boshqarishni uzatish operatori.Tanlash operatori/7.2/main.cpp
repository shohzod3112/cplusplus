// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Oy raqamini kiriting. Shu oy qaysi faslda ekanligini
// chiqaruvchi programma tuzilsin.(Masalan: May oyining
// tartib raqami 5 kiritilsa, javob Bahor)

#include <iostream>

using namespace std;

int main()
{
    int a;

    cout << "a = "; cin >> a;

    switch(a)
{
    case 1:
    case 2:
    case 12: cout << "Qish" << endl;
        break;

    case 3:
    case 4:
    case 5: cout << "Bahor" << endl;
        break;
    case 6:
    case 7:
    case 8: cout << "Yoz" << endl;
        break;
    case 9:
    case 10:
    case 11: cout << "Kuz" << endl;
        break;

    default: cout << "Bunday yil oyi yo'q!!!" << endl;
}
    return 0;
}
