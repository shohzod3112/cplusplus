// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Yil faslini bildiruvchi 1, 2, 3, 4 sonlaridan birini kiriting.
// Shu faslga tegishli oylarni chiqaruvchi programma tuzilsin.
// Masalan: 1 - Qish; 2 - Bahor; 3 - Yoz; 4 - Kuz; bo'lsin.
// 2 soni kiritilsa, natija ekranga quyidagicha shaklda chiqsin.
// Bahor fasli oylari:
// 1. Mart
// 2. Aprel
// 3. May

#include <iostream>

using namespace std;

int main()
{
    int a;

    cout << "1 - Qish; 2 - Bahor; 3 - Yoz; 4 - Kuz son kiriting!!!" << endl;
    cout << "a = "; cin >> a;

    switch(a)
{
    case 1: cout << "Qish fasli oylari:\n1. Yanvar\n2. Fevral\n3. Mart" << endl;
        break;

    case 2: cout << "Bahor fasli oylari:\n1. Mart\n2. Aprel\n3. May" << endl;
        break;

    case 3: cout << "Yoz fasli oylari:\n1.Iyun\n2.Iyul\n3.Avgust" << endl;
        break;

    case 4: cout << "Kuz fasli oylari:\n1.Sentabr\n2.Oktabr\n3.Noyabr" << endl;
        break;

    default: cout << "Bunday yil fasli yo'q!!!" << endl;
}

    return 0;
}
