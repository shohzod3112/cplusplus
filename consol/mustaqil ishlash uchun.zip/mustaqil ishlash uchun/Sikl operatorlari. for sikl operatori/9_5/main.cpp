// Muallif : Ro'ziyev Shohzod
// Sana : 19.03.2013
// Maqsad : N natural soni berilgan. N gacha bo'lgan 3 ga bo'linadigan lekin
// 5 ga bo'linmaydigan sonlarni chiqaruvchi dastur tuzing.

#include <iostream>

using namespace std;

int main()
{
    int N, i;

    cout << "N = "; cin >> N;

    for (i = 1; i <= N; i++)
{
    if (i % 3 == 0 && i % 5 != 0)
        cout << i << endl;
}
    return 0;
}
