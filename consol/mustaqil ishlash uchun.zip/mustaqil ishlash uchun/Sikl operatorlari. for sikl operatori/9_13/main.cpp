// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Quyidagi ifodani hisoblovchi dastur tuzing.
// (1 + sin 0.1) * (1 + sin 0.2) ... (1 + sin 10);
// Paramertli sikl operatori takrorlanishlar soni oldindan ma'lum bo'lgan hollarda ishlatiladi.
// Siklning takrorlanishlar sonini aniqlovchi formulani siz "Parametrli sikl operatori"
// mavzusidan topishingiz mumkin.
// 0.1, 0.2, ... 10 lar gradusda berilgan. Radianga o'tkazish kerak.

#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main()
{
    float const pi = 3.14159;
    float s = 1, i;

    for(i = 0.1; i < 10.1; i += 0.1)
{
    s *= 1 + sin(i * pi / 180);
}
    cout << "s = " << setprecision(2) << fixed << s << endl;

    return 0;
}
