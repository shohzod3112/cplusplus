// Muallif : Ro'ziyev Shohzod
// Sana : 19.03.2013
// Maqsad : N soni berilgan.Shu songacha bo'lgan tub sonlarni
// chiqaruvchi programma tuzing.

#include <iostream>

using namespace std;

int main()
{
    int N, i, j, k = 0;

    cout << "N = "; cin >> N;

    for(i = 2; i <= N; i++)
{
    k = 0;

    for(j = 2; j < i; j++)

    if(i % j == 0)
{
    k++;
}
    if(k == 0)
        cout << i << "   ";
}
    /*
    // 2-usul
    int N, i, j;
    bool tub = true;

    cout << "N = "; cin >> N;

    for(i = 2; i <= N; i++)
{
    tub = true;
    for(j = 2; j < i; j++)
{
    if(i % j == 0)
        {
            tub = false; break;
        }
}
    if(tub)
        cout << i << endl;
}*/
    return 0;
}
