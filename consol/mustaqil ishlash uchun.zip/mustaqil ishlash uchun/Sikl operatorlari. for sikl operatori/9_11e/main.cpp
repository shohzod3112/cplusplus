// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: n natural soni berilgan.Quyidagilarni hisoblovchi programma tuzing.
// e) (i + 1) / (i + 2)
// f) pow((1 + 1 / i!),2)

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n;
    float i, e = 1, f = 1, m = 1;

    cout << "n = "; cin >> n;

    for(i = 2; i <= n; i++)
{
    e *= (i + 1) / (i + 2);
    f *= (1 + 1 / (m * i));
}
    cout << "e = " << setprecision(2) << fixed << e << endl;
    cout << "f = " << setprecision(2) << fixed << f << endl;

    return 0;
}
