// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: n natural soni berilgan.Quyidagilarni hisoblovchi programma tuzing.
// f) 1 / sin(1) + 1 / (sin(1) + sin(2)) + ... + 1 / (sin(1) + sin(n))
// e) cos(1) / sin(1) + (cos(1) + cos(2)) / (sin(1) + sin(2)) + ... + (cos(1) + ... + cos(n)) / (sin(1) + ... + sin(n))

#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

int main()
{
    int n;
    float a = 0, b = 0, c = 0, f = 0, e = 0;

    cout << "n = "; cin >> n;

    for(int i = 1; i <= n; i++)
{
    a += sin(i);
    f += 1 / a;
    b += cos(i);
    c += sin(i);
    e += b / c;
}
    cout << "f = " << setprecision(2) << fixed  << f << endl;
    cout << "e = " << setprecision(2) << fixed  << e << endl;

    return 0;
}
