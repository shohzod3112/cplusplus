// Muallif : Ro'ziyev Shohzod
// Sana : 10.11.2012
// Maqsad : N natural soni berilgan. Shu son bo'luvchilarini chiqaruvchi
// programma tuzing.Masalan: 30 ning bo'luvchilari 1, 2, 3, 5, 6, 10, 15, 30

#include <iostream>

using namespace std;

int main()
{
    int N, i, k = 0;

    cout << "N = "; cin >> N;

    for(i = 1; i <= N; i ++)
{
    if(N % i == 0)
    cout << i << endl;
}
    return 0;
}
