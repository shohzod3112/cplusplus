// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: n natural soni berilgan.Quyidagilarni hisoblovchi programma tuzing.
// d) sqrt(2 + sqrt(2 + ... + sqrt(2))) n ta idiz
// e) sqrt(3 + sqrt(6 + ... + sqrt(3 * (n - 1) + srqt(3 * n))))

#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

int main()
{
    int n;
    float i, d = 0, e = 0;

    cout << "n = "; cin >> n;

    for(i = n; i > 0; i--)
{
    d = sqrt(2 + d);
    e = sqrt(3 * i + e);
}
    cout << "d = " << setprecision(2) << fixed << d << endl;
    cout << "e = " << setprecision(2) << fixed << e << endl;

    return 0;
}
