// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: n natural soni berilgan.Quyidagilarni hisoblovchi programma tuzing.
// c) 1 / i!;

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    float i, n, s = 0, p = 1;

    cout << "n = "; cin >> n;

    for(i = 1; i <= n; i++)
{
    p *= i;
    s += 1 / p;
}
    cout << "1 / n! = "  << setprecision(2) << fixed << s << endl;

    return 0;
}
