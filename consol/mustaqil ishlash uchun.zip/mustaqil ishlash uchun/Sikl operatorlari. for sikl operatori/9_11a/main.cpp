// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: n natural soni berilgan.Quyidagilarni hisoblovchi programma tuzing.
// a) 1 / i * i;
// b) 1 / pow(i,3);
// d) 1 / ((2 * i),2);

#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

int main()
{
    int n;
    float i, a = 0, b = 0, d = 0;

    cout << "n = "; cin >> n;

    for(i = 1; i <= n; i++)
{
    a += 1 / (i * i);
    b += 1 / (i * i * i);
    d += 1 / pow((2 * i),2);
}
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
    cout << "d = " << d << endl;

    return 0;
}
