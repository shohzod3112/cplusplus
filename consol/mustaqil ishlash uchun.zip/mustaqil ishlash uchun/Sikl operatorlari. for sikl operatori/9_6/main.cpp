// Muallif : Ro'ziyev Shohzod
// Sana : 19.03.2013
// Maqsad : N natural soni berilgan. Shu son tub yoki tub emasligini
// aniqlovchi programma tuzing.Faqat o'ziga va birga bo'linadigan son
// tub son deyiladi.

#include <iostream>

using namespace std;

int main()
{
    int N, i;
    bool tub = true;

    cout << "N = ";  cin >> N;

    for (i = 2; i < N; i++)
{
    if(N % i == 0)
{
    tub = false;
}
}
    if (tub == true)
{
    cout << "tub son" << endl;
}
    else
{
    cout << "tub son EMAS" << endl;
}
    return 0;
}
