// Muallif :Ro'ziyev Shohzod
// Sana : 19.03.2013
// Maqsad : N natural soni berilgan.Shu songacha bo'lgan mukammal sonlarni
// chiqaruvchi dastur tuzing.

#include <iostream>

using namespace std;

int main()
{
    int N, s = 0, i, j;

    cout <<"N = "; cin >> N;

    for (i = 1; i < N; i ++)
{
    s = 0;

    for (j = 1; j < i; j ++)

    if(i % j == 0)
{
    s += j;
}
    if (s == i)
{
    cout << i << endl;
}}
    return 0;
}
