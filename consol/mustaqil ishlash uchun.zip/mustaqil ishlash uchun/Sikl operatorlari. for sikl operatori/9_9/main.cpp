// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: N natural soni berilgan.N gacha do'st sonlarni chiqaruvchi programma tuzilsin. Agar birinchi son
// bo'luvchilari yig'indisi ikkinchi songa, ikkinchi son bo'luvchilari yig'indisi birinchi songa
// teng bo'lsa, bu sonlar do'st sonlar deyiladi.

#include <iostream>

using namespace std;

int main()
{
    int N, i, j, s, c;

    cout << "N = "; cin >> N;

    for(i = 2; i <= N; i++)
{
    s = 0;

    for(j = 1; j < i; j++)
    {
        if(i % j == 0)

        s += j;
    }
    c = 0;
    for(j = 1; j < s; j++)
    {
        if(s % j == 0)

        c += j;
    }
    if(c == i && i != s)
    {
        cout << i <<"\t" << s << endl;
    }
}
    return 0;
}
