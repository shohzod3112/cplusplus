// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: a haqiqiy soni va n natural soni berilgan.Quyidagilarni hisoblovchi programma tuzing.
// a) pow(a,n);
// b) a * (a + 1)...(a + n - 1);

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n;
    float i, a, b = 1, s = 1;

    cout << "a = "; cin >> a;
    cout << "n = "; cin >> n;

    for(i = 1; i <= n; i++)
{
    s *= a;
    b *= a + i - 1;
}
    cout << "a = " << setprecision(2) << fixed << s << endl;
    cout << "b = " << setprecision(2) << fixed << b << endl;

    return 0;
}
