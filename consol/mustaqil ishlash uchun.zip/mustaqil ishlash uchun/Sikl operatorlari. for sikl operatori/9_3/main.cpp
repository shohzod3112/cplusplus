// Muallif : Ro'ziev Shohzod
// Sana : 16.11.2012
// Maqsad : N natural soni berilgan. Shu son mukammal yoki mukammal emasligini
// aniqlovchi dastur tuzung.O'zidan boshqa bo'luvchilari yig'indisi o'ziga
// teng bo'lgan son mukammal son deyiladi.Masalan: 6 = 1+2+3 mukammal son

#include <iostream>

using namespace std;

int main()
{
    int N, i, k = 0;

    cout << "N = "; cin >> N;

    for (i = 1; i < N; i ++)
{
    if(N % i == 0)
{
    k += i;
}
}
    if(k == N)
{
    cout << "Mukammal son" << endl;
}
    else
{
    cout << "Mukammal son emas" << endl;
}
    return 0;
}
