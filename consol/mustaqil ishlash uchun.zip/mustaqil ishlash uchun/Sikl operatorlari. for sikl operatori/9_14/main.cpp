// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: X, A haqiqiy, n natural soni berilgan.Quyidagi ifodani hisoblovchi programma tuzilsin.

#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

int main()
{
    int n;
    float X, A, i, s;

    cout << "n = "; cin >> n;
    cout << "A = "; cin >> A;
    cout << "X = "; cin >> X;

    s = X;

    for(i = 1; i <= n; i++)
{
    s = pow((s + A),2);
}
    s += A;

    cout << "s = " << setprecision(2) << fixed << s << endl;

    return 0;
}
