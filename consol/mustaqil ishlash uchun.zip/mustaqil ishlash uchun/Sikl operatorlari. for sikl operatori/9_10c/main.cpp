// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: n natural soni berilgan.Quyidagilarni hisoblovchi programma tuzing.
// (1 + 1/(1*1))*(1+1/(2*2))*...*(1+1/(n*n))
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n;
    float a = 1, i;

    cout << "n = "; cin >> n;

    for(i = 1; i <= n; i++)

    a *= (1 + 1/(i*i));

    cout << setprecision(2) << fixed << a << endl;

    return 0;
}
