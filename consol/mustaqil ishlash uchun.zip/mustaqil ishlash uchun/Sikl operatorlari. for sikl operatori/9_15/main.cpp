// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: n natural soni berilgan.Quyidagi ifodani hisoblovchi programma tuzilsin.

#include <iostream>
#include <math.h>
#include <iomanip>

using namespace std;

int main()
{
    unsigned int n, s = 0, p;

    cout << "n = "; cin >> n;

    for(int i = 1; i <= n; i++)
{
    p = 1;

    for(int j = i; j <= 2 * i; j++)

     p *= j;
     s += p;
}
    cout << "s = " << setprecision(2) << fixed << s << endl;

    return 0;
}
