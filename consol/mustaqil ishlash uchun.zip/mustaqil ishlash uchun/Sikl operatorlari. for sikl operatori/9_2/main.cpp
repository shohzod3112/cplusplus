// Muallif : Ro'ziev Shohzod
// Sana : 11.11.2012
// Maqsad : N natural soni berilgan.Shu son bo'luvchilari yig'indisini
// chiqaruvchi programma tuzing.Masalan: N = 15; javob 24 (chunki 1 + 2 + 3 + 5 + 15)

#include <iostream>

using namespace std;

int main()
{
    int N, i, j, S = 0;

    cin >> N;

    for (i = 1; i <= N; i ++)
{
    if (N % i == 0) { S += i; }
}
    cout << S << endl;

    return 0;
}
