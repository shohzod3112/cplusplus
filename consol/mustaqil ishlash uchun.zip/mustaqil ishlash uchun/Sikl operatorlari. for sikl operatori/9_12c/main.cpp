// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: a haqiqiy soni va n natural soni berilgan.Quyidagilarni hisoblovchi programma tuzing.
// b) a * (a + 1)...(a + n - 1);
// d) a * (a - n) * (a - 2 * n) * . * (a - n * n);
// c) 1 / a + 1 / (a * (a + 1)) + ... + 1 / (a * (a + 1)...(a + n));

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n;
    float i, a, b = 1, c = 0, d = 1;

    cout << "a = "; cin >> a;
    cout << "n = "; cin >> n;

    for(i = 0; i <= n; i++)
{
    b *= a + i;
    d *= a - i * n;
    c += 1 / b;
}
    cout << "b = " << setprecision(2) << fixed << b << endl;
    cout << "d = " << setprecision(2) << fixed << d << endl;
    cout << "c = " << setprecision(2) << fixed << c << endl;

    return 0;
}
