// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: n natural soni berilgan.Quyidagilarni hisoblovchi programma tuzing.
// a)2pow(n)
// b)n!;n!=1*2*3*...*n; ya'ni 1 dan n gacha bo'lgan sonlar ko'paytmasi.

#include <iostream>

using namespace std;

int main()
{
    int n, a = 1, b = 1;

    cout << "n = "; cin >> n;

    for(int i = 1; i <= n; i++)
{

    a *= 2;
    b *= i;
}
    cout << "2 ning " << n << " chisi = " << a << endl;
    cout << n << " faktorial = " << b << endl;

    return 0;
}
