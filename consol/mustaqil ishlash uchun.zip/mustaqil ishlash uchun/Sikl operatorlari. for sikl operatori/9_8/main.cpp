// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: N natural soni berilgan. N gacha bo'lgan pifagor sonlarini chiqaruvchi
// programma tuzilsin. c * c = a * a + b * b shartni qanoatlantiruvchi
// sonlar pifagor sonlari deyiladi.

#include <iostream>

using namespace std;

int main()
{
    int N, a, b, c;

    cout << "N = "; cin >> N;

    for(a = 2; a <= N; a++)

    for(b = 2; b <= N; b++)

    for(c = 2; c <= N; c++)
{
    if((c * c == a * a + b * b) && a != b && a != c && b != a && b != c)
{
    cout << a << " " << b << " " << c << endl;
}
    if(a == c && a == b && b == a && b == c && c == a && c == b)
        break;
}
    return 0;
}
