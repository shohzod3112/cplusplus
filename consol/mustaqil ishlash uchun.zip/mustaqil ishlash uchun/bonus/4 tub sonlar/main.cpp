// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: N natural soni berilgan.Shu son tub yoki tub emasligini aniqlovchi
// programma tuzilsin. Faqat 1 aga va o'ziga bo'linadigan son tub son deyiladi.

#include <iostream>

using namespace std;

int main()
{
    int n;
    bool tub = true;

    cout << "n = "; cin >> n;

    for(int i = 2; i < n; i++)
{
    if(n % i == 0)
        tub = false;
}
    if(tub)
        cout << "Tub son" << endl;
    else
        cout << "Tub son emas" << endl;

    return 0;
}
