// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: N natural soni berilgan.Shu songacha bo'lgan tub chiqaruvchi
// programma tuzilsin. Faqat 1 aga va o'ziga bo'linadigan son tub son deyiladi.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int n, sana = 0;

    cout << "n = "; cin >> n;

    for(int i = 2; i <= n; i++)
{
    bool tub = true;

    for(int k = 2; k < i; k++)
   {
    sana++;
    if(i % k == 0)
    {
        tub = false;
        //tub emasligi aniq bo'ldi siklni tugatsa ham bo'ladi
        break;
    }
   }
    if(tub)
    cout << i << endl;
}
   cout << sana;
    return 0;
}
