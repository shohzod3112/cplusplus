// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: N natural soni berilgan.Quyidagi ifodani hisoblovchi programma tuzilsin.
// 1 * 2 + 2 * 3 * 4 + .. + n * (n - 1)... * 2 * n
#include <iostream>

using namespace std;

int main()
{
    int n, p = 1, s = 0;

    cout << "n = "; cin >> n;

    for(int i = 1; i <= n; i++)
{
    p = 1;

    for(int j = i; j <= 2 * i; j++)

    p *= j;
    s += p;

    cout << s << endl;
}
    return 0;
}
