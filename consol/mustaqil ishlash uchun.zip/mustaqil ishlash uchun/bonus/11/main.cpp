// Muallif: Ro'ziyev Shohzod
// Sana: 12.11.2014
// Maqsad: Noldan farqli bo'lmagan x haqiqiy soni berilgan.
// Quyidagi ifodani hisoblovchi programma tuzilsin.

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    float x, s, i;

    cout << "x = "; cin >> x;

    s = x * x;
    i = 256;

    while(i > 1)
{
    s = x * x + i / s;
    i /= 2;
}
    s = x / s;
    cout << "s = " << setprecision(2) << fixed << s << endl;

    return 0;
}
