// Muallif: Ro'ziyev Shohzod
// Sana: 12.11.2014
// Maqsad: N natural soni berilgan. Shu son raqamlari yig'indisini
// topuvchi dastur tuzilsin.

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n, m, s = 0;

    cout << "n = "; cin >> n;

    while(n > 0)
{
    m = n % 10;
    n /= 10;
    s += m;
}
    cout << "s = " << s << endl;

    return 0;
}
