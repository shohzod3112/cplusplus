// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: n natural soni berilgan.Quyidagi qonuniyatni n - xadini hisoblovchi
// programma tuzilsin. (while sikl operatori oraqali)

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n;
    float a = 1, k = 0;

    cout << "n = "; cin >> n;

    while(k < n)
{
    k++;
    a = a * k + 1 / k;
}
    cout << "a = " << setprecision(2) << fixed << a << endl;

    return 0;
}
