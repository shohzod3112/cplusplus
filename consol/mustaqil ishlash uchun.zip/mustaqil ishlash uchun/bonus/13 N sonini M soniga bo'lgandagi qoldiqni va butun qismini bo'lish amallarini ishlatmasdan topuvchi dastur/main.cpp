// Muallif: Ro'ziyev Shohzod
// Sana: 12.11.2014
// Maqsad: N sonini M soniga bo'lgandagi qoldiqni va butun qismini bo'lish
// amallarini (/,%) ishlatmasdan topuvchi dastur tuzilsin.

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n, m, i = 0;

    cout << "n = "; cin >> n;
    cout << "m = "; cin >> m;

    while(n >= m)
{
    n -= m;
    i++;
}
    cout << "Butun qismi = " << i << endl;
    cout << "Qoldiq = " << n << endl;

    return 0;
}
