// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Quyidagi qonuniyatni n - xadini hisoblovchi programma tuzilsin.
// (while sikl operatori oraqali)

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    float s = 103, i = 101;

    while(i > 0)
{
    s = i + 1 / s;
    i -= 2;
}
    s = 1 / s;

    cout << "s = " << setprecision(2) << fixed << s << endl;

    return 0;
}
