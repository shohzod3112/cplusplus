// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Kiritilgan N soni so'z bilan ifodalaydigan programma tuzilsin.0 < N < 100
// Masalan: 75 kiritilsa yetmish besh shaklida chiqsin.

#include <iostream>

using namespace std;

int main()
{
    int n, onlar, birlar;

    cout << "0 < N < 100 oraliqda son kiritilsin" << endl;
    cout << "n = "; cin >> n;

    onlar = n / 10;
    birlar = n % 10;

    switch(onlar)
{
    case 1: cout << "O'n "; break;
    case 2: cout << "Yigirma "; break;
    case 3: cout << "O'ttiz "; break;
    case 4: cout << "Qirq "; break;
    case 5: cout << "Ellik "; break;
    case 6: cout << "Oltmish "; break;
    case 7: cout << "Yetmish "; break;
    case 8: cout << "Sakson "; break;
    case 9: cout << "To'qson "; break;
}
    switch(birlar)
{
    case 1: cout << "bir"; break;
    case 2: cout << "ikki "; break;
    case 3: cout << "uch "; break;
    case 4: cout << "to'rt "; break;
    case 5: cout << "besh "; break;
    case 6: cout << "olti "; break;
    case 7: cout << "yetti "; break;
    case 8: cout << "sakkiz "; break;
    case 9: cout << "to'qqiz "; break;
}
    return 0;
}
