// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: N natural soni berilgan.Shu songacha bo'lgan mukammal sonlarni chiqaruvchi
// programma tuzilsin. O'zidan boshqa bo'luvchilar yig'indisi o'ziga teng bo'lgan son
// mukammal son deyiladi.Masalan: 6 = 1 + 2 + 3 mukammal son

#include <iostream>

using namespace std;

int main()
{
    int n, i, s = 0;

    cout << "n = "; cin >> n;

    for(i = 1; i < n; i++)
{
    if(n % i == 0)
        s += i;

}    if(s == n)
        cout << "Mukammal son" << endl;
    else
        cout << "Mukammal son emas" << endl;

    return 0;
}
