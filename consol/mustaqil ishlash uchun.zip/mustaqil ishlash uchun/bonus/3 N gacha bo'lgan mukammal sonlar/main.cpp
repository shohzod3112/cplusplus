// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: N natural soni berilgan.Shu songacha bo'lgan mukammal sonlarni chiqaruvchi
// programma tuzilsin. O'zidan boshqa bo'luvchilar yig'indisi o'ziga teng bo'lgan son
// mukammal son deyiladi.Masalan: 6 = 1 + 2 + 3 mukammal son

#include <iostream>

using namespace std;

int main()
{
    int n, k, s;

    cout << "n = "; cin >> n;
    cout << "N gacha bo'lgan mukammal sonlar " << endl;

    for(int i = 2; i <= n; i++)
{
    s = 0;
    for(k = 1; k < i; k++)
{
    if(i % k == 0)
        s += k;

}    if(s == i)
        cout << s << endl;
}
    return 0;
}
