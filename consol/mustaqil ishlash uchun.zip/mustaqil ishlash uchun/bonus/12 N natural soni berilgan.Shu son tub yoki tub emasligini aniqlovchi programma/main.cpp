// Muallif: Ro'ziyev Shohzod
// Sana: 12.11.2014
// Maqsad: N natural soni berilgan.Shu son tub yoki tub emasligini aniqlovchi
// programma tuzilsin. while sikl operatori orqali.

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n, i = 2;
    bool tub =true;

    cout << "n = "; cin >> n;

    while(i < n)
{
    if(n % i == 0)
    {
        tub = false;
        break;
    }
    i++;
}
    if(tub)
        cout << "tub son" << endl;
    else
        cout << "tub son emas" << endl;

    return 0;
}
