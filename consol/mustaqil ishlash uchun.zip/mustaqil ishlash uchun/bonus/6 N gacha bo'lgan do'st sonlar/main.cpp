// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: N natural soni berilgan.N gacha bo'lgan do'st sonlarni chiqaruvchi
// programma tuzilsin. Agar birinchi son bo'luvchilari yig'indisi ikkinchi songa,
// ikkinchi son bo'luvchilari yig'indisi birinchi songa teng bo'lsa,
// bu sonlar do's sonlar deyiladi.

#include <iostream>

using namespace std;

int main()
{
    int n, i, k, s, c, soni = 0;

    cout << "n = "; cin >> n;

    for(i = 2; i <= n; i++)
{
        s = 0;

    for(k = 1; k <= i / 2; k++)
{
    if(i % k == 0)
        s += k;
}
    if(s > i)
{
    c = 0;

    for(k = 1; k <= s / 2; k++)
{
    if(s % k == 0)
        c += k;
        soni ++;
}
    if(i == c)
    cout << i << "\t" << s << endl;
}}
    cout << "soni = " << soni << endl;
    return 0;
}
