// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: A va B butun sonlari berilgan. (a < b) shu sonlar orasidagi
// butun sonlarni chiqaruvchi programma tuzilsin.
// Masalan: a = 5; b = 10; bo'lsa, javob 5, 6, 7, 8, 9, 10

#include <iostream>

using namespace std;

int main()
{
    int A, B;

    metka:

    cout << "A = "; cin >> A;
    cout << "B = "; cin >> B;

    if(A > B)
{
    cout << "Qayta kiriting" << endl;
    goto metka;
}
    nishon:

    if(A <= B)
{

    cout << A << endl;

    A++;

    goto nishon;
}
   return 0;
}
