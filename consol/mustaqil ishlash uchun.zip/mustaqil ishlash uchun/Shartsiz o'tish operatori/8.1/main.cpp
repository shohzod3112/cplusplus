// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: (1,5) oraliqdagi haqiqiy sonni kiritishni taklif qiluvchi va
// kiritilgan son bu oraliqqa tegishli bo'lmasa qayta kiritishni
// taklif qiluvchi programma tuzilsin.

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    float n;

    s :

    cout << "(1,5) oraliqda son kiriting!!!" << endl;
    cout << "n = "; cin >> n;

    if((n < 1) || (n > 5))

    goto s;

    cout << "1 < " << setprecision(2) << fixed << n << " < 5 " << "oraliqda son kiritildi!!!" << endl;

    return 0;
}
