// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Hafta kunini raqamini kirituvchi, agar bunday hafta kuni
// bo'lmasa, hafta kunini qayta kiritishni yoki programmani
// tugatishni taklif qiluvchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    int n, a;

    metka :

    cout << "Hafta kunini kiriting!!!" << endl;
    cout << "n = "; cin >> n;

    if((n < 1) || (n > 7))
{
    cout << "Hafta kuni noto'g'ri kiritildi." << endl;

    cout << "\nQayta kiritish uchun 1 ni\nTugatish uchun 2 ni kiriting!!!" << endl;

    cin >> a;

        if (a == 1)
    {
            goto metka;
    }
        else cout << "Xayr" << endl;
}
    else
    cout << "Hafta kuni to'g'ri kiritildi!!!" << endl;

    return 0;
}
