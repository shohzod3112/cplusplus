// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Kvadrat tenglamani ildizlarini topuvchi programma tuzilsin. Diskriminant
// manfiy bo'lgan holatda, koeffitsienlarini qayta kiritish yoki programmani
// tugatishni taklif qilinsin.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float a, b, c, d, x, x1, x2;
    char k;

    kiritish:

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;

    d = b * b - 4 * a * c;

    if(d < 0)
{
    cout << "Qayta kiritishni xoxlaysizmi? (y/n)" << endl;

    cin >> k;

    if(k == 'y' || k == 'Y')

    goto kiritish;
}
    else
{
    if(d == 0)
{
    cout << "Tenglama bitta ildizga ega";

    x = -b / (2 * a);
    cout << "x = " << x << endl;
}
    else
{
    x1 = (-b + sqrt(d)) / (2 * a);
    x2 = (-b - sqrt(d)) / (2 * a);

    cout << "x1 = " << x1 << endl;
    cout << "x2 = " << x2 << endl;
}
}
    return 0;
}
