// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Kvadrat tenglamani ildizlarini topuvchi programma tuzilsin. Diskriminant
// manfiy bo'lgan holatda, koeffitsienlarini qayta kiritish yoki programmani
// tugatishni taklif qilinsin.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int a, b, c, d, x, x1, x2, i;

    nishon:

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;

    d = pow((-b),2) - 4 * a * c;

    if(d < 0)
{
    cout << "Qayta kiritish 1.\nProgrammani tugatish 2." << endl;

    cin >> i;

    if(i == 1)

    goto nishon;

    else return 0;
}
    if(d == 0)
{
    x = -b / (2 * a);
}
    if(d > 0)
{
    x1 = (-b + sqrt(d)) / (2 * a);
    x2 = (-b - sqrt(d)) / (2 * a);

    cout << "x1 = " << x1 << endl;
    cout << "x2 = " << x2 << endl;
}
    return 0;
}
