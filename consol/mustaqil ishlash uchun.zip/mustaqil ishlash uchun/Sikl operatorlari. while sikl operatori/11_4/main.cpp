// Muallif: Ro'ziyev Shohzod
// Sana:27.09.2014
// Maqsad: N natural soni berilgan. Shu son tub yoki tub emasligini aniqlovchi programma tuzilsin.
// While sikl operatori orqali

#include <iostream>

using namespace std;

int main()
{
    /*
    int n, i = 2, l = 0;

    cout << "n = "; cin >> n;
    // 1 - usul
    while(i < n)
{
    if(n % i == 0)
    l++;
    i++;
}
    if(l == 0)
        cout << "tub" << endl;
    else
        cout << "tub emas" << endl;
*/
    // 2 - usul

    bool tub = true;
    int k = 1, n;

    cout << "n = "; cin >> n;

    while(k < n - 1)
    {
        k++;
        if(n % k == 0)
        {
            tub = false;
            break;
        }
    }
    if(tub == true)
            cout << "tub son" << endl;
    else
            cout << "tub son EMAS" << endl;

    return 0;
}
