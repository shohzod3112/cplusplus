// Muallif: Ro'ziyev Shohzod
// Sana:27.09.2014
// Maqsad: N natural soni berilgan. Quyidagi qonuniyatni n - xadini hisoblovchi programma tuzilsin.
// While sikl operatori orqali

#include <iostream>

using namespace std;

int main()
{
    int n;
    float a = 1, k = 1;

    cout << "n = "; cin >> n;

    while(k <= n)
{
    a = k * a + 1 / k;
    cout << a << endl;
    k++;
}
    return 0;
}
