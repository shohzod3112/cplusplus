// Muallif: Ro'ziyev Shohzod
// Sana:27.09.2014
// Maqsad: Quyidagi ifodani hisoblovchi programma tuzilsin.While sikl operatori orqali

#include <iostream>

using namespace std;

int main()
{
    int n = 101;
    float s = 103;

    while(n >= 1)
{
    s = n + 1 / s;
    n -= 2;;
}
    s = 1 / s;
    cout << s << endl;

    return 0;
}
