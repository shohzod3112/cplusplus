// Muallif: Ro'ziyev Shohzod
// Sana:27.09.2014
// Maqsad: N sonini M soniga bo'lgandagi qoldiqni va butun qismini bo'lish amallarini (/,%)
// ishlatmasdan topuvchi dastur tuzilsin.
// While sikl operatori orqali

#include <iostream>

using namespace std;

int main()
{
    int n, m, butun = 0;

    cout << "n = "; cin >> n;
    cout << "m = "; cin >> m;

    while(n >= m)
{
    n -= m;
    butun++;
}
    cout << "Butun qismi = " << butun << endl;
    cout << "Qoldiq qismi = " << n << endl;

    return 0;
}
