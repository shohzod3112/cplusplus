// Muallif: Ro'ziyev Shohzod
// Sana:27.09.2014
// Maqsad: Quyidagi ifodani hisoblovchi programma tuzilsin.While sikl operatori orqali

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    int n = 256;
    float s, x;

    cout << "x = "; cin >> x;

    s = x * x;

    while(n > 1)
{
    s = x * x + n / s;
    n /= 2;
}
    s = x / s;
    cout << setprecision(2) << fixed << s << endl;

    return 0;
}
