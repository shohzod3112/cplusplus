// Muallif: Ro'ziyev Shohzod
// Sana:27.09.2014
// Maqsad: N natural soni berilgan. Shu son raqamlari yig'indisini chiqaruvchi dastur tuzilsin.
// While sikl operatori orqali

#include <iostream>

using namespace std;

int main()
{
    int n, m, s = 0;

    cout << "n = "; cin >> n;

    while(n > 0)
{
    m = n % 10;
    s += m;
    n = n / 10;
}
    cout << "Raqamlari yig'indisi = " << s << endl;
    return 0;
}
