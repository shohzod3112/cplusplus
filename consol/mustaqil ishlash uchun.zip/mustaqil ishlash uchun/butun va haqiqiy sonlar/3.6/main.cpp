// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad:  Koordinatalari (x1,y1) va (x2,y2) bo'lgan nuqtalar berilgan.Shu
// nuqtalar orasidagi masofani hisoblovchi programma tuzing.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float x1, x2, y1, y2, d;

    cout << "x1 = "; cin >> x1;
    cout << "y1 = "; cin >> y1;
    cout << "x2 = "; cin >> x2;
    cout << "y2 = "; cin >> y2;

    d = sqrt(pow((x1 - x2),2) + pow((y1 - y2),2));

    cout << "d = " << d << endl;

    return 0;
}
