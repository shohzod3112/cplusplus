// Muallif : Ro'ziyev Shohzod
// Maqsad : A sonini B soniga bo'lib, verguldan keyin 4 xona aniqlikda
// chiqaruvchi dastur tuzing.

#include <iostream>
#include <iomanip> // Sarlaha faylini qo'shamiz.

using namespace std;

int main()
{
    float A, B, C;

    cout << "A = "; cin >> A;
    cout << "B = "; cin >> B;

    C = A / B;

    C -= (int)A / (int)B;

    cout << C << endl;

    cout << setprecision(4) << fixed << C << endl;

    return 0;
}
