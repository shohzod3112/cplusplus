// To'g'ri burchakli uchburchakning gepotenuzasi (c) va kateti (a)
// berilgan. Uchburchakning ikkinchi kateti (b) va uchburchakka ichki
// chizilgan aylana radiusini topuvchi programma tuzilsin.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float a, b, c, r;

    cout << "a = "; cin >> a;
    cout << "c = "; cin >> c;

    b = sqrt(pow(c,2) - pow(a,2));

    r = (a + b + c) / (a * b);

    cout << "b = " << b << endl;
    cout << "r = " << r << endl;

    return 0;
}
