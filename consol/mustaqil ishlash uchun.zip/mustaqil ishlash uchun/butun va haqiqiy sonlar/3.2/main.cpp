// Muallif : Ro'ziyev Shohzod
// Sana: 10.11.2012
// Maqsad: n natural soni berilgan.(9<n<100) Quyidagini aniqlovchi programma tuzing.
// 1.n soni oxirgi raqami. 2. n soni birinchi raqami 3. Raqamlari yig'indisi

#include <iostream>

using namespace std;

int main()
{
    int n, oxirgi, birinchi, Summa, i;

    cout << "n=" ; cin >> n;

    if (9 < n && n < 100)
 {
    birinchi = n / 10; oxirgi = n % 10;

    Summa = birinchi + oxirgi;
}
    cout << birinchi << endl;

    cout <<  oxirgi << endl;

    cout << Summa << endl;

    return 0;
}
