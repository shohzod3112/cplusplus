// Muallif :  Ro'ziev Shohzod
// Sana : 10.11.2012
// Maqsad : n natural soni berilgan.(1000>n>99) Shu sonni yuzlar xonasini aniqlovchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    int n, yuzlar;

    cout << "son kiriting " ; cin >> n;

    if (99 < n && n <1000)    yuzlar = n/100;

    else cout << "99<n<1000 oraliqda kiriting";

    cout << "y=" << yuzlar ;

    return 0;
}
