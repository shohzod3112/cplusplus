// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: A va B haqiqiy sonlari berilgan. A sonini B soniga bo'lib butun
// qismini aniqlovchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    // 1-usul
    float a, b;
    int butun;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;

    butun = a / b;

    cout << "Butun qismi = " << butun << endl;

    return 0;
}
/*// A va B haqiqiy sonlari berilgan. A sonin B soniga bo'lib butun
// qismini aniqlovchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    // 2-usul
    float a, b, butun;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;

    butun = (int) a / (int) b;

    cout << "Butun qismi = " << butun << endl;

    return 0;
}
*/
