// Muallif:Ro'ziyev Shohzod
// Sana:12.03.2013
// Maqsad:Uchburchakning tomonlari a,b,c berilgan.Geron formulasidan
// foydalangan holda uchburchak yuzini hisoblovchi programma tuzing.
// Natijani verguldan keyingi ikkita xonasigacha yaxlitlang.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int a, b, c, p, s;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;

    p = (a + b + c) / 2;

    s = sqrt(p * (p - a) * (p - b) * (p - c));

    cout << "P = " << p << endl;

    cout << "S = " << s << endl;

    return 0;
    system("pause");
}
