// Muallif : Roziev Shohzod
// Sana : 10.11.2012
// Maqsad : Arifmetik progressiyani birinchi hadi a, ayirmasi d, hadlari soni n
// berilgan. Arifmetik progressiyaning n ta hadini hisoblovchi programma tuzing.

#include <iostream>

using namespace std;

int main()
{
    int n, d, a, S;

    cout << "Progressiyaning birinchi hadini kiriting\n a = "; cin >> a;

    cout << "Progressiyaning ayirmasini kiriting\n d = "; cin >> d;

    cout << "Progressiyaning hadlari sonini kiriting\n n = "; cin >> n;

    S=(2 * a + d * (n - 1)) * n / 2;

    cout << "\n" << "Yig'indi = " << S << endl;

    return 0;
}
