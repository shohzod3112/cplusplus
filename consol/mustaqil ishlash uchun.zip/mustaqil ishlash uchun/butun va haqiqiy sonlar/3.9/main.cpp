// Muallif : Ro'ziev Shohzod
// Maqsad : a va b sonlar berilgan. Shu sonlar o'rnini almashtiruvchi
// programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    int a, b, k;

    cout << "a = " ; cin >> a;

    cout << "b = " ; cin >> b;
{
/*    // 1-usul
    k = a; a = b; b = k;
*/
    // 2-usul
    a = a + b;
    b = a - b;
    a = a - b;

}
    cout << "a = " << a << "\n" << "b = " << b << endl;

    return 0;
}
