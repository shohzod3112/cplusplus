#include <iostream>

using namespace std;

int main()
{
    int a[10] = {0};
    int n, s = 1, k = -1, maxraj = 1;

    cout << "n = "; cin >> n;

    for(int i = 0; i < n; i ++)
    {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }
    s = a[0];
    for(int i = 1; i < n; i ++)
    {
        maxraj *= i;
        s += k * a[i] / maxraj;
        k *= -1;
    }

    cout << "Massiv elementlari yig'indisi = " << s << endl;
    return 0;
}
