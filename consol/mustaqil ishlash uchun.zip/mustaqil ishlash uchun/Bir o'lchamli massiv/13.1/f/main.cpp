#include <iostream>

using namespace std;

int main()
{
    int a[10] = {0};
    int n, s = 1;

    cout << "n = "; cin >> n;

    for(int i = 0; i < n; i += 2)
    {
        cout << "a[" << i << "] = ";
        cin >> a[i];
        s *= a[i];
    }

    cout << "Massiv elementlari yig'indisi = " << s << endl;
    return 0;
}
