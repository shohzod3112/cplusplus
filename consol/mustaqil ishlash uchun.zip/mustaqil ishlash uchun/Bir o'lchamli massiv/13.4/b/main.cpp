#include <iostream>

using namespace std;

int main()
{
    float a[10] = {0};
    float n, s = 1;

    cout << "n = "; cin >> n;

    for(int i = 0; i < n; i++)
    {
        cout << "a[" << i << "] = ";
        cin >> a[i];
        if(a[i] > 0)
        s *= a[i];
        else break;
    }
        cout << "s = " << s << endl;

    return 0;
}
