#include <iostream>

using namespace std;

int main()
{
    float a[10] = {0};
    float n, s = 0, orta, k;

    cout << "n = "; cin >> n;

    for(int i = 0; i < n; i++)
    {
        cout << "a[" << i << "] = ";
        cin >> a[i];

        s *= a[i];
        k = i + 1;
    }
        cout << "O'rta arifmetigi = " << s / k << endl;

    return 0;
}
