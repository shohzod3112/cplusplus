#include <iostream>

using namespace std;

int main()
{
    float a[10] = {0};
    float n, s = 0;

    cout << "n = "; cin >> n;

    for(int i = 0; i < n; i++)
    {
        cout << "a[" << i << "] = ";
        cin >> a[i];

        s += a[i];
    }
        cout << "O'rta arifmetigi = " << s / n << endl;

    return 0;
}
