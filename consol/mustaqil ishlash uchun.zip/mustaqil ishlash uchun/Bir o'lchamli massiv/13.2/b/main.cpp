#include <iostream>

using namespace std;

int main()
{
    int a[10] = {0};
    int n;

    cout << "n = "; cin >> n;

    for(int i = 0; i < n; i++)
    {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }
    for(int i = 0; i < n; i++)
    {
        cout << "a[" << i << "] = ";
        cout << a[i] * a[i];
        cout << endl;
    }

    return 0;
}
