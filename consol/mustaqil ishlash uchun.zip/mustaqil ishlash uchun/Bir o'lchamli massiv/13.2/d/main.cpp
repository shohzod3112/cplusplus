#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    int a[10] = {0};
    int n, k;

    cout << "n = "; cin >> n;

/*    for(int i = 0; i < n; i++)
    {
        cout << "a[" << i << "] = ";
        cin >> a[i];
    }
  */
    for(int i = 0; i < n; i++)
    {
        k = pow(2, i) + pow(3,(i + 1));
        a[i] = k;

        cout << "a[" << i << "] = ";
        cout << a[i];
        cout << endl;
    }

    return 0;
}
