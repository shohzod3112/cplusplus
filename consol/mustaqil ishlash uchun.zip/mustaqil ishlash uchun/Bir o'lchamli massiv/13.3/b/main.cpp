#include <iostream>

using namespace std;

int main()
{
    int a[10] = {0};
    int n, u0 = 1, u1 = 1, u;
    int f1 = 0, f2 = 1, f;

    cout << "n = "; cin >> n;

    for(int i = 0; i < n; i++)
    {
        u = u0 + u1;
        u0 = u1;
        u1 = u;
        f = f1 + f2;
        f1 = f2;
        f2 = f;

        a[i] = f2 + u1;
    }
    for(int i = 0; i < n; i++)
    {
        cout << "a[" << i << "] = " << a[i] << endl;
    }
    return 0;
}
