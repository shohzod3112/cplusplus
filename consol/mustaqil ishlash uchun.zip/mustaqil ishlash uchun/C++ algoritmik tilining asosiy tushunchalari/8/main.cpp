// Muallif : Ro'ziev Shohzod
// Sana : 10.11.2012
// Maqsad : R1, R2, R3 qarshiliklar parallel ulangan.Umumiy qarshilikni
// hisoblovchi programma tuzing.

#include <iostream>

using namespace std;

int main()
{
    float R, R1, R2, R3;

    cout << "\n Birinchi qarshilikni kiriting:\tR1 = "; cin >> R1;

    cout << "\n Ikkinchi qarshilikni kiriting:\tR2 = "; cin >> R2;

    cout << "\n Uchinchi qarshilikni kiriting:\tR3 = "; cin >> R3;

    R = R1 * R2 * R3 / (R1 * R2 + R1 * R3 + R2 * R3);

    cout << "\n" << "R = " << R << "\n" << endl;

    return 0;
}
