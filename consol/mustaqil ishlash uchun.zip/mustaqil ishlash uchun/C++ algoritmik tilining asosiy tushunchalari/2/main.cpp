// Muallif : Ro'ziev Shohzod
// Sana : 10.11.2012
// Maqsad : To'g'ri burchakli uchburchakning katetlari a va b berilgan.
// Uchburchakning gepatenuzasi (c) yuzi (s)ni hisoblovchi programma tuzing

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float a, b, c, s;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;

    c = sqrt(pow(a,2) + pow(b,2));

    //C++ da bo'luvchi haqiqiy son(float) bo'lsa nuqta(.) dan foydalaniladi.

    s = 1./2 * a * b;

    cout << "c = " << c << "\n" << "s = " << s << endl;

    return 0;
}
