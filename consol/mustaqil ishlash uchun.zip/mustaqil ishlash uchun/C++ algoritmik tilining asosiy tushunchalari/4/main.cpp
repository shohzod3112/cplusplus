// Muallif : Ro'ziev Shohzod
// Sana : 10.11.2012
// Maqsad : H balandlikdan erkin tushgan toshning uchish uzoqligini aniqlovchi
// programa tuzilsin.(g = 10 erkin tushish tezlanishi)

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    const int g = 10;
    float H, t;

    cout << "H = "; cin >> H;

    t = sqrt(2 * H / g);

    cout << "t = " << t << endl;

    return 0;
}
