// Muallif : Ro'ziev Shohzod
// Sana : 10.11.2012
// Maqsad : Ikkita haqiqiy musbat son berilgan. Shu sonlarning o'rta
// arifmetigini va o'rta geometrigini aniqlovchi programma tuzilsin.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float a, b, orta_arifmetig, orta_geometrik;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;

    orta_arifmetig = (a + b) / 2;
    orta_geometrik = sqrt(a * b);

    cout << "O'rta arifmetigi = " << orta_arifmetig << endl;
    cout << "O'rta geometrigi = " << orta_geometrik << endl;

    return 0;
}
