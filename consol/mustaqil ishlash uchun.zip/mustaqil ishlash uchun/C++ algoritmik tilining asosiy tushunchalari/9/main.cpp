// Muallif : Ro'ziev Shohzod
// Sana : 10.11.2012
// Maqsad : X,Y Qiymatlar berilgan.Quyidagi ifodani hisoblash
// programmasini tuzing.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float x, y, z;

    cout << "\n" << "Birinchi sonni kiriting\tx = "; cin >> x;

    cout << "\n" << "Ikkinchi sonni kiriting\ty = "; cin >> y;

    z=(fabs(x) - fabs(y)) / (1 + fabs(x * y));

    cout << "z = " << z << endl;

    return 0;
}
