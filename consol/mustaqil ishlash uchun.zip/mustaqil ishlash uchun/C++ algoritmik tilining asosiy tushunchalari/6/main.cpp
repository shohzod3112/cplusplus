// Muallif : Ro'ziev Shohzod
// Sana : 10.11.2012
// Maqsad : L uzunlikdagi matematik mayatnikning tebranish davrini
// hisoblovchi programma tuzilsin.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    const float pi = 3.14;
    const int g = 10;

    float L, T;

    cout << "L = "; cin >> L;

    T = 2 * pi * sqrt(L / g);

    cout << "T = "  << T << endl;

    return 0;
}
