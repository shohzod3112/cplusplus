// Muallif : Ro'ziev Shohzod
// Sana : 10.11.2012
// Maqsad : Kubning hajmini va yon tomoni yuzasini hisoblovchi programma tuzing.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float a, V, S;

    cout << "a = "; cin >> a;

    V = pow(a,3);

    S = 6 * pow(a,2);

    cout << "V = " << V << "\n" << "S = " << S << endl;

    return 0;
}
