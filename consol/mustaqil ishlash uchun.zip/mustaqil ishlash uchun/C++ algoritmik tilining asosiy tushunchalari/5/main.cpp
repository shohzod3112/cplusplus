// Muallif : Ro'ziev Shohzod
// Sana : 10.11.2012
// Maqsad : Teng tomonliuchburchakning tomoni (a) berilgan. Uchburchakning
// yuzini hisoblovchi programma tuzilsin.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float a, S;

    cout << "a = "; cin >> a;

    S = sqrt(3)/4 * pow(a,2);

    cout << "S = " << S << endl;

    return 0;
}
