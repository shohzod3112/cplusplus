// Muallif : Ro'ziev Shohzod
// Sana : 10.11.2012
// Maqsad : Temperaturasi t1, bo'lgan v1 hajmli suv temperaturasi t2
// bo'lgan v2 hajmli suvga aralashtiriladi. Hosil bo'lgan
// suvning hajmi va temperaturasini aniqlovchi programma tuzilsin.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float t1, t2, v1, v2, V, T;

    cout << "v1 = "; cin >> v1;
    cout << "v2 = "; cin >> v2;
    cout << "t1 = "; cin >> t1;
    cout << "t2 = "; cin >> t2;

    T = ((v1 + v2) * t2 + v1 * t1) / (2 * v1 + v2);
    V = v1 + v2;

    cout << "T = " << T << endl;
    cout << "V = " << V << endl;

    return 0;
}
