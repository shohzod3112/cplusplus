// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: a, b, c haqiqiy musbat sonlari berilgan. Tomonlari shu sonlarga
// teng bo'lgan uchburchak mavjudligi tekshirilsin. (Uchburchakning
// har ikkala tomoni yig'indisi uchinchi tomondan katta bo'lishi kerak.

#include <iostream>

using namespace std;

int main()
{
    float a, b, c;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;

    if((c < a + b) && (b < a + c) && (a < b + c))
{
    cout << "true" << endl;
}
    else cout << "false" << endl;
    return 0;
}
