// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Ikkita butun son berilgan.Shu sonlar toq sonlar bo'lsa, true
// qiymat chiqaruvchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;

    if(!(a % 2 == 0) && !(b % 2) == 0)

    cout << "true" << endl;

    else cout << "false" << endl;

    return 0;
}
