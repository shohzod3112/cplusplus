// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: A = true, B = false, C = true, D = false bo'lsa, quyidagi ifoda
// natijasini aniqlang. ((A && B) || (C && D)) && (A || B)

#include <iostream>


using namespace std;

int main()
{
    bool a, A = true, B = false, C = true, D = false;

    a = ((A && B) || (C && D)) && (A || B);
/*
    a = (false || false) && true;
    a = false && true;
    a = false;
*/
    cout << "Ifodaning qiymati = " << a << endl;

    return 0;
}
