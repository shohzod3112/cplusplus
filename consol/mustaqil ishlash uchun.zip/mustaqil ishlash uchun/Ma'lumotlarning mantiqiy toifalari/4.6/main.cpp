// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Ikkita butun son berilgan.Shu sonlardan biri toq sonlar bo'lsa,
// ikkinchisi juft son bo'lsa, true qiymat chiqaruvchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;

    if(((a % 2 == 1) && ((b % 2) == 0)) || ((a % 2 == 0) && ((b % 2) == 1)))

    cout << "true" << endl;

    else cout << "false" << endl;

    return 0;
}
