// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Berilgan N sonini juft toqligi tekshirilsin. N soni juft bo'lsa,
// true natija olinsin.

#include <iostream>

using namespace std;

int main()
{
    int N;

    cout << "N = "; cin >> N;

    if(N % 2 == 0)
{
    N = true;
    cout << "N = " << N << endl;
}
    else
{
    N = false;
    cout << "N = " << N << endl;
}
    return 0;
}
