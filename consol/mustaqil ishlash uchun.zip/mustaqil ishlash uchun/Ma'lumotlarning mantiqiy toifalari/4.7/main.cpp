// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: a, b, c haqiqiy sonlari berilgan. Shu sonlarni pifagor ekanligi
// tekshirilsin. Agar berilgan sonlar c * c = a * a + b * b shartni
// qanoatlantirsa bu sonlar pifagor sonlari deyiladi. a, b, c sonlari
// pifagor sonlari bo'lsa true, aks holda false qiymat chiqarilsin.

#include <iostream>

using namespace std;

int main()
{
    float a, b, c;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;

    if((c * c == a * a + b * b) || (b * b == a * a + c * c) || (a * a == b * b + c * c))
{
    cout << "true" << endl;
}
    else cout << "false" << endl;
    return 0;
}
