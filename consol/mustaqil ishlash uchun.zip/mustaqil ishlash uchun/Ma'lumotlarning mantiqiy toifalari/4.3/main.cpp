// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Ikkita haqiqiy son berilgan.Shu sonlar har xil ishorali bo'lsa,
// true qiymat chiqaruvchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    float a, b;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;

    if((a < 0 || b > 0) && (a > 0) || (b < 0))

    cout << "\n" << true << endl;

    else cout << "\n" << false << endl;

    return 0;
}
