// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Devorda to'g'ri to'rtburchak shaklida tirqich bor.Tirqichning o'lchami x, y.
// Shu tirqichga g'ishtni sig'ish yoki si'gmasligini aniqlovchi programma tuzilsin.
// G'ishtning o'lchamlari a, b, c;

#include <iostream>

using namespace std;

int main()
{
    int a, b, c, x, y;

    cout << "G'ishtning o'lchamlarini kiriting!!!" << endl;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;

    cout << "Tirqichning o'lchamlarini kiriting!!!" << endl;

    cout << "x = ";  cin >> x;
    cout << "y = ";  cin >> y;

    if(((x >= a) && (y >= b) || (x >= a) && (y >= c)) ||
       ((x >= b) && (y >= a) || (x >= b) && (y >= c)) ||
       ((x >= c) && (y >= a) || (x >= c) && (y >= b)))
{
    cout << "\n" << "G'isht tirqichga sig'adi!!!" << endl;
}
    else cout << "\n" << "G'isht tirqichga sig'maydi!!!" << endl;

    return 0;
}
