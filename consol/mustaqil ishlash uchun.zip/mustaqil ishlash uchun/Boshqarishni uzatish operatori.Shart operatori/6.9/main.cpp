// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Uchta haqiqiy son berilgan.Shu sonlardan (1,3) oraliqqa tegishlilarini aniqlovchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    float a, b, c;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;

    if(1 < a && a < 3) cout << "\n" << "a = " << a << endl;
    if(1 < b && b < 3) cout << "\n" << "b = " << b << endl;
    if(1 < c && c < 3) cout << "\n" << "c = " << c << endl;

    return 0;
}
