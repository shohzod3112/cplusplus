// x, y, z haqiqiy sonlari berilgan. Quyidagilarni aniqlovchi programma
// max(x, y, z)
// min(x, y, z)

#include <iostream>

using namespace std;

int main()
{
    float x, y, z, min, max;

    cout << "x = "; cin >> x;
    cout << "y = "; cin >> y;
    cout << "z = "; cin >> z;

    max = (x > y) ? x : y;
    max = (max < z) ? z : max;

    min = (x < y) ? x : y;
    min = (min > z) ? z : min;

    cout << "\n" << "max = " << max << endl;
    cout << "\n" << "min = " << min << endl;

    return 0;
}
