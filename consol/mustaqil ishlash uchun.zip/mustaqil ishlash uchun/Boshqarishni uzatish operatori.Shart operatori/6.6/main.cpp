// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: x, y haqiqiy sonlari berilgan. Z ni hisoblovchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    float x, y, Z;

    cout << "x = "; cin >> x;
    cout << "y = "; cin >> y;

    if(x > y)
{
    Z = x - y;
}
    else
{
    Z = y - x + 1;
}
    cout << "\n" << "Z = " << Z << endl;

    return 0;
}
