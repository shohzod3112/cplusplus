// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: x, y haqiqiy sonlari berilgan. Ularning kichigini sonlar yig'indisining yarmiga, kattasini
// ko'paytmasining ikkilanganiga almashtiruvchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    float x, y, max, min;

    cout << "x = "; cin >> x;
    cout << "y = "; cin >> y;

    max = (x > y) ? x : y;
    min = (x < y) ? x : y;

    max = 2 * x * y;
    min = (x + y) / 2;

    cout << "Kattasi = " << max << endl;
    cout << "Kichigi = " << min << endl;

    return 0;
}
