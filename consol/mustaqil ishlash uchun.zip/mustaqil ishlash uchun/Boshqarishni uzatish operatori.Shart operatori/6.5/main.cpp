// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: a, b, c haqiqiy sonlari berilgan. Bu sonlar a >= b >= c tengsizlikni
// qanoatlantirsa, ularning qiymatini 2 marta orttiruvchi, aks holda ular
// qiymatini absolyut qiymatga almashtiruvchi programma tuzilsin.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float a, b, c;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;

    if((a >= b) && (b >= c))
{
        a = 2 * a;
        b = 2 * b;
        c = 2 * c;
}
    else
{
    a = fabs(a);
    b = fabs(b);
    c = fabs(c);
}
    cout << endl;
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
    cout << "c = " << c << endl;

    return 0;
}
