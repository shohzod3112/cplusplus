// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Ikita haqiqiy son berilgan. Agar birinchi son ikkinchisidan kichig
// yoki teng bo'lsa, birinchi sonni nolga aylantiruvchi, aks holda
// o'zgarishsiz qoldiruvchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    float a, b;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;

    cout << endl;

    if(a <= b)
{
        a = 0;
        cout << "a = " << a << "\n" << "b = " << b << endl;
}
    else
{
        cout << "a = " << a << "\n" << "b = " << b << endl;
}
        return 0;
}
