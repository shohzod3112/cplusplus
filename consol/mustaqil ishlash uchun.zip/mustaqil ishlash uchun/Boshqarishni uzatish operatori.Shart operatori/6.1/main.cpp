// x, y haqiqiy sonlari berilgan. Quyidagilarni aniqlovchi programma tuzing.
// max(x,y); (X va Y sonlaridan kattasi ekranga chiqarilsin)
// min(x,y); (X va Y sonlaridan kichigi ekranga chiqarilsin)

#include <iostream>

using namespace std;

int main()
{
    float x, y, min, max;

    cout << "x = "; cin >> x;
    cout << "y = "; cin >> y;

    max = (x > y) ? x : y;
    min = (x < y) ? x : y;

    cout << "\n" << "max = " << max << endl;
    cout << "\n" << "min = " << min << endl;

    return 0;
}
