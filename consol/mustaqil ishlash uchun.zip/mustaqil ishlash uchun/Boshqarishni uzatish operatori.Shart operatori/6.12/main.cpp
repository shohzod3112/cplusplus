// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: a, b, c, d haqiqiy sonlari berilgan. Agar bu sonlar d >= c >= b >= a shartni qanoatlantirsa,
// har bir sonni ularning kattasiga almashtiruvchi, a > b > c > d shartni qanoatlantirsa  sonlarni
// o'zgartirishsiz qoldiruvchi qoldiruvchi, aks holda har bir sonni kvadratga oshiruvchi programma

#include <iostream>

using namespace std;

int main()
{
    float a, b, c, d;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;
    cout << "d = "; cin >> d;

    if(d >= c && c >= b && b >= a)
{
    c = d;
    b = d;
    a = d;
}
    else
{
    if(a > b && b > c && c > d)
{

}
    else
{
    a *= a;
    b *= b;
    c *= c;
    d *= d;
}
}
    cout << "\n" << "a = " << a << endl;
    cout << "\n" << "b = " << b << endl;
    cout << "\n" << "c = " << c << endl;
    cout << "\n" << "d = " << d << endl;

    return 0;
}
