// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: x, y, z haqiqiy sonlari berilgan. Quyidagilarni aniqlovchi programma
// max(x + y + z, xyz)
// min*min(x + y + z / 2, xyz) + 1

#include <iostream>

using namespace std;

int main()
{
    float x, y, z, min, max;

    cout << "x = "; cin >> x;
    cout << "y = "; cin >> y;
    cout << "z = "; cin >> z;

    max = ((x + y + z) > x * y * z) ? (x + y + z) : x * y * z;
    min = ((x + y + z / 2) < x * y * z) ? (x + y + z / 2) : x * y * z;

    min = min * min + 1;

    cout << "max = " << max << endl;
    cout << "min = " << min << endl;

    return 0;
}
