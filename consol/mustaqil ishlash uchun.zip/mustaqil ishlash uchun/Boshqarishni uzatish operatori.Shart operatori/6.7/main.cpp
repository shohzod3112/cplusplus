// Ikita haqiqiy son berilgan. Agar birinchi son ikkinchisidan katta
// bo'lsa, birinchi sonni, aks holda ikkala sonni chiqaruvchi programma

#include <iostream>

using namespace std;

int main()
{
    float a, b;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;

    cout << endl;

    if(a > b) cout << "a = " << a << endl;
    else
{
    cout << "a = " << a << endl;
    cout << "b = " << b << endl;
}
    return 0;
}
