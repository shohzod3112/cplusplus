// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Uchta haqiqiy son berilgan. Ulardan manfiy bo'lmaganlarining kvadratini chiqaruvchi programma tuzilsin.

#include <iostream>

using namespace std;

int main()
{
    float a, b, c;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;

    if(a > 0) cout << "\n" << "a = " << a * a << endl;
    if(b > 0) cout << "\n" << "b = " << b * b << endl;
    if(c > 0) cout << "\n" << "c = " << c * c << endl;

    return 0;
}
