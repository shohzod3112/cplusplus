// Muallif: Ro'ziyev Shohzod
// Sana: 11.11.2014
// Maqsad: Kvadrat tenglama ildizlarini topuvchi programma tuzilsin.

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    float a, b, c, d, x1, x2, x;

    cout << "a = "; cin >> a;
    cout << "b = "; cin >> b;
    cout << "c = "; cin >> c;

    d = b * b - 4 * a * c;

    if(d > 0)
{
    x1 = (- b + sqrt(d)) / (2 * a);
    x2 = (- b - sqrt(d)) / (2 * a);
    cout << "\n" << "x1 = " << x1 << endl;
    cout << "\n" << "x2 = " << x2 << endl;
}
    if(d == 0)
{
    x = - b / (2 * a);
    cout << "\n" << "x = " << x << endl;
}
    if(d < 0)
{
    cout << "\n" << "Tenglama haqiqiy ildizga ega emas!!!" << endl;
}
    return 0;
}
